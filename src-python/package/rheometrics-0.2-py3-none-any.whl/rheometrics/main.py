from scipy.signal import savgol_filter


def smooth_data(data, window=10, polyorder=1):
    return savgol_filter(data, window, polyorder)


def hello():
    print("Hello from world of Rheology!")
